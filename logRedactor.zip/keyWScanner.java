package logRedactor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.JOptionPane;


//This is the final working copy as of April 6 8:52 am
public class keyWScanner
{
	public void justScan(String logFilePath1, String keyWfilePath1, String opRedactFilePath1, String keyWDel1 )
	{
		String fileName = logFilePath1;
		String keyfileName = keyWfilePath1; // Location of the file to be
		String opfilName = opRedactFilePath1  +"\\" + "Scan_Report.txt";
		String keyWDel2 = keyWDel1;
		String line = null;
		String lineRepl = null;
		PrintWriter out = null;
		File f = new File(opfilName);

		// Delete the report if it already exists
		if (f.exists())
		{
			f.delete();
		}
		// Read the text file and create the invalchars array

		try 
		{

			Scanner inFile1 = new Scanner(new File(keyfileName));
			StringBuilder sb = new StringBuilder();
			out = new PrintWriter(new FileWriter(opfilName, true), true);
			while (inFile1.hasNext()) 
			{
				sb.append(inFile1.nextLine());
			}

			String[] invalChars = sb.toString().split(keyWDel2);
			
			if (sb.toString().indexOf(keyWDel2) == -1)
			{
				String delimNotFound1 = "Delimiter " + keyWDel2 +" was not dound in your keyword file, please check";
				JOptionPane.showMessageDialog(null, delimNotFound1, "Error", JOptionPane.ERROR_MESSAGE);
				System.exit(1);
				
			}


			for (int i = 0; i < invalChars.length; i++)
			{
				// Reading the keywords from the text file
				FileReader fileReader = new FileReader(fileName);
				BufferedReader bufferedReader = new BufferedReader(fileReader);
				int sensVar = 0;
				while ((line = bufferedReader.readLine()) != null) 
				{
					if (line.indexOf(invalChars[i]) != -1)
					{
						lineRepl = line;
						sensVar = sensVar + 1;
					} // if loop ends
					else
					{
						// out.write(line);
					}
				} // While loop ends

				if (sensVar < 1)
				{
					out.write(i + 1 + ") " + invalChars[i] + " information not found" + "\r\n");
					System.out.println(i + 1 + ") " + invalChars[i] + " information not found");
				}
				else
				{
					out.write(i + 1 + ") " + sensVar + " instances of " + invalChars[i] + " found" + "\r\n");
					System.out.println(i + 1 + ") " + sensVar + " instances of " + invalChars[i] + " found");
					// System.out.println(line);
				}
				bufferedReader.close();
			} // For loop ends
		}
		catch (FileNotFoundException ex) 
		{
			System.out.println(	"Unable to open file '" + fileName + "'");

		}

		catch (IOException ex) 
		{		
			System.out.println("Error reading file '"+ fileName + "'");
		}

		finally 
		{
			out.flush();
			out.close();
		}

	}
		
		


}
