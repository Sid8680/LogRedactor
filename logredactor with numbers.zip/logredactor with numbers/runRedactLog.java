package logRedactor;

public class runRedactLog

{
	public void getLogR (String lf1, String kw1, String op, String kt, String kd)
	{
		String lfPath = lf1;
		String kwfPath = kw1;
		String opPath = op;
		String redactType = kt;
		String keywDelemit = kd;
		iterArr iArr = new iterArr();
		iArr.redactLogs(lfPath, kwfPath, opPath,redactType,keywDelemit);
	}
}
