package logRedactor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.JOptionPane;
public class iterArr {

	public void redactLogs(String logFilePath, String keyWfilePath, String opRedactFilePath, String redType, String keyWDel)

	{
		String fileName = logFilePath;
		String keyWDel1 = keyWDel;
		String keyfileName = keyWfilePath;
		String opfilName = opRedactFilePath +"\\" + "RedactedLog.txt";
		String line = null;
		String textFabLog = null;
		PrintWriter out = null;
		int j = 0;
		// Read the text file and create the invalchars array
		try {
			Scanner inFile1 = new Scanner(new File(keyfileName));
			StringBuilder sb = new StringBuilder();
			File f = new File(opfilName);

			// Delete the report if it already exists

			if (f.exists())
			{
				f.delete();
				System.out.println("File Deleted");
				
			}

			out = new PrintWriter(new FileWriter(opfilName, true), true);
			while (inFile1.hasNext())
			{
				sb.append(inFile1.nextLine());
			}
			inFile1.close();
			String[] invalChars = sb.toString().split(keyWDel1);
			
			if (sb.toString().indexOf(keyWDel1) == -1)
			{
				String delimNotFound = "Delimiter " + keyWDel1 +" was not dound in your keyword file, please check";
				JOptionPane.showMessageDialog(null, delimNotFound, "Error", JOptionPane.ERROR_MESSAGE);
				System.exit(1);
				
			}
			
			// Reading the keywords from the text file
			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			int sensVar = 0;
			while ((line = bufferedReader.readLine()) != null)
			{
				j = j + 1;
				for (int i = 0; i < invalChars.length; i++)
				{
					// Search for sensitive information
					if (line.indexOf(invalChars[i]) != -1)
					{
						// lineRepl = line;
						if (redType == "Line")
							{
								textFabLog = line.replace(line, "XXXXXXXX");
							}
						else if (redType == "Keyword")
							{
								textFabLog = line.replace(invalChars[i], "XXXXXXXX");
							}
		
						
						
						line = textFabLog;
						sensVar = sensVar + 1;
					} // if loop ends
					else
					{
						// out.write(line);
					}
				} // For loop ends
				/*if (textFabLog != null)
				{
					out.write(textFabLog);
				}
				else
				{
					out.write(line);
				}*/
				out.write(j + "--" + line + "\r\n");
				System.out.println(j + "--" + line );
				//System.out.println(sensVar + "--" + textFabLog);
			} // While loop ends
			bufferedReader.close();
		}
		catch (FileNotFoundException ex) 
		{
			System.out.println("Unable to open file '" + fileName + "'");
		} 
		catch (IOException ex) 
		{
			System.out.println("Error reading file '" + fileName + "'");
		}

		finally 
		{
			out.flush();
			out.close();
		}
	}
}
