package logRedactor;

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;

public class logRedactorScPage extends JFrame {
	static logRedactorScPage frame = null;
	private JPanel contentPane;
	
	private JTextField txtLocationKeyW;
	private JTextField txtLocationLog;
	private JTextField txtLocationRedLog;
	private JTextField textKeywDelim;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try {
					frame = new logRedactorScPage();
					frame.setVisible(true);					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public logRedactorScPage() {
		
		initializeComponents();
		createEvents();
		
		
	}

	private void initializeComponents() 
	{
		// TODO Auto-generated method stub
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 680, 360);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLocation(100,100);
		setContentPane(contentPane);
		
		//Some ground rules
		setTitle("Log  Redactor");
		setResizable(false);
		setLocation(100,100);
		centerFrame();
		
		txtLocationLog = new JTextField();
		txtLocationLog.setToolTipText("location of your log file");
		txtLocationLog.setFont(new Font("Arial", Font.ITALIC, 11));
		txtLocationLog.setColumns(30);
		
		txtLocationKeyW = new JTextField();
		txtLocationKeyW.setToolTipText("location of your keyword file");
		txtLocationKeyW.setFont(new Font("Arial", Font.ITALIC, 11));;
		txtLocationKeyW.setColumns(30);
		
		
		txtLocationRedLog = new JTextField();
		txtLocationRedLog.setToolTipText("location of your redacted log file");
		txtLocationRedLog.setFont(new Font("Arial", Font.ITALIC, 11));
		txtLocationRedLog.setColumns(30);
		
		//This is used only to set the delimiter in the keyword file - default is a comma
		textKeywDelim = new JTextField(",");
		textKeywDelim.setFont(new Font("Arial", Font.ITALIC, 11));
		textKeywDelim.setColumns(1);
		textKeywDelim.setToolTipText("This is the delimiter in your keyword file, default is a comma");
		
		//Add the buttons
		
		JButton btnBrowse = new JButton("Browse Log File");
		btnBrowse.addMouseListener(new MouseAdapter() 
		{
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				JFileChooser fcLog = new JFileChooser();
				fcLog.setMultiSelectionEnabled(true);
		        fcLog.setCurrentDirectory(new File("."));
		        fcLog.setFileSelectionMode(JFileChooser.FILES_ONLY);
				int returnValLog = fcLog.showOpenDialog((fcLog));
				if (returnValLog == JFileChooser.APPROVE_OPTION)
				{
					String logFile = fcLog.getSelectedFile().getAbsolutePath();
					txtLocationLog.setText(logFile); 
					
				}
				
			}
		});
		JButton btnBrowseKW = new JButton("Browse Keyword file");
		btnBrowseKW.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				JFileChooser fcKeyWord = new JFileChooser();
				fcKeyWord.setMultiSelectionEnabled(true);
				fcKeyWord.setCurrentDirectory(new File("."));
				fcKeyWord.setFileSelectionMode(JFileChooser.FILES_ONLY);
				int returnValLog = fcKeyWord.showOpenDialog((fcKeyWord));
				if (returnValLog == JFileChooser.APPROVE_OPTION)
				{
					String keyWfile = fcKeyWord.getSelectedFile().getAbsolutePath();
					txtLocationKeyW.setText(keyWfile); 
					
				}
			}
		});
		
			
		JButton btnBrowseRedLog = new JButton("Browse Redacted File Location");
		btnBrowseRedLog.addMouseListener(new MouseAdapter() 
		{
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				JFileChooser fcRedLog = new JFileChooser();
				fcRedLog.setMultiSelectionEnabled(true);
				fcRedLog.setCurrentDirectory(new File("."));
				fcRedLog.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int returnValLog = fcRedLog.showOpenDialog((fcRedLog));
				if (returnValLog == JFileChooser.APPROVE_OPTION)
				{
					String keyRedLog = fcRedLog.getSelectedFile().getAbsolutePath();;
					txtLocationRedLog.setText(keyRedLog); 
					
				}
			
			
			}
		});
				
		String[] redactModes = new String[] {"Line","Keyword"};
		DefaultComboBoxModel<String> comboModel = new DefaultComboBoxModel<String>(redactModes);
		JComboBox jcomboBoxRedType = new JComboBox(comboModel);
						
		jcomboBoxRedType.setToolTipText("Please select if you want to redact just the keyword or the entire line");
		
		JLabel lblNewLabel = new JLabel("Select Redaction Mode");
		lblNewLabel.setToolTipText("Please select if you want to redact just the keyword or the entire line");
		
		JButton btnOk = new JButton("Redact File");
		btnOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				//Check if any of the input field is blank
				if (txtLocationLog.getText().isEmpty() || txtLocationKeyW.getText().isEmpty()|| txtLocationRedLog.getText().isEmpty())
				{
					JOptionPane.showMessageDialog(null, "Please select all inputs and then click OK", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				//Check if any of the provided inputs is invalid
				
				File flogref = new File(txtLocationLog.getText());
				if (flogref.exists()== false)
				{
					JOptionPane.showMessageDialog(null, "Log file does not exist", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}

				File fkeyW = new File(txtLocationKeyW.getText());
				if (fkeyW.exists()== false)
				{
					JOptionPane.showMessageDialog(null, "Keyword file does not exist", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				File fredacted = new File(txtLocationRedLog.getText());
				if (fredacted.exists()== false)
				{
					JOptionPane.showMessageDialog(null, "Output location for redacted file is invalid", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				if (textKeywDelim.getText().length() > 1)
				{
					JOptionPane.showMessageDialog(null, "The delimiter used is more than 1 character", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				
				//This is where the magic occurs
				runRedactLog runRD = new runRedactLog();
				
				String redactModeType = (String) jcomboBoxRedType.getSelectedItem();
				runRD.getLogR(txtLocationLog.getText(),txtLocationKeyW.getText(), txtLocationRedLog.getText(),redactModeType,textKeywDelim.getText());
				JOptionPane.showMessageDialog(null, "File has been redacted", "Done", JOptionPane.INFORMATION_MESSAGE);
				try {
					Desktop.getDesktop().open(new File(txtLocationRedLog.getText()));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		
		JButton btnJustScan = new JButton("Scan for keywords");
		btnJustScan.setToolTipText("Click this if you just want to scan for keywords, no Redaction!");
		btnJustScan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
					
				//Check if any of the input field is blank
				if (txtLocationLog.getText().isEmpty() || txtLocationKeyW.getText().isEmpty()|| txtLocationRedLog.getText().isEmpty())
				{
					JOptionPane.showMessageDialog(null, "Please select all inputs and then click OK", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				//Check if any of the provided inputs is invalid
				
				File flogref = new File(txtLocationLog.getText());
				if (flogref.exists()== false)
				{
					JOptionPane.showMessageDialog(null, "Log file does not exist", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}

				File fkeyW = new File(txtLocationKeyW.getText());
				if (fkeyW.exists()== false)
				{
					JOptionPane.showMessageDialog(null, "Keyword file does not exist", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				File fredacted = new File(txtLocationRedLog.getText());
				if (fredacted.exists()== false)
				{
					JOptionPane.showMessageDialog(null, "Output location for redacted file is invalid", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				if (textKeywDelim.getText().length() > 1)
				{
					JOptionPane.showMessageDialog(null, "The delimiter used is more than 1 character", "ERROR", JOptionPane.ERROR_MESSAGE);
					return;
				}
				

				
				//This is where the magic occurs
				keyWScanner kwScan = new keyWScanner();
								
				kwScan.justScan(txtLocationLog.getText(),txtLocationKeyW.getText(), txtLocationRedLog.getText(),textKeywDelim.getText());
				JOptionPane.showMessageDialog(null, "File has been scanned", "Done", JOptionPane.INFORMATION_MESSAGE);
				try {
					Desktop.getDesktop().open(new File(txtLocationRedLog.getText()));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			
			}
		});
		
		
		
		
		
		
		
		
		
		
		//Set the locations of the components
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(20)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnJustScan)
							.addGap(163)
							.addComponent(btnOk)
							.addPreferredGap(ComponentPlacement.RELATED, 179, Short.MAX_VALUE)
							.addComponent(btnCancel)
							.addGap(31))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnBrowse)
									.addPreferredGap(ComponentPlacement.RELATED, 196, Short.MAX_VALUE)
									.addComponent(txtLocationLog, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnBrowseKW)
									.addPreferredGap(ComponentPlacement.RELATED, 174, Short.MAX_VALUE)
									.addComponent(txtLocationKeyW, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(btnBrowseRedLog, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
									.addPreferredGap(ComponentPlacement.RELATED, 124, Short.MAX_VALUE)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(jcomboBoxRedType, GroupLayout.PREFERRED_SIZE, 157, GroupLayout.PREFERRED_SIZE)
										.addComponent(txtLocationRedLog, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
							.addGap(18)
							.addComponent(textKeywDelim, GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE)
							.addGap(23))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(txtLocationLog, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnBrowse))
					.addGap(27)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(txtLocationKeyW, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnBrowseKW)
						.addComponent(textKeywDelim, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
					.addGap(32)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(txtLocationRedLog, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnBrowseRedLog))
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(jcomboBoxRedType, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 94, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnJustScan)
						.addComponent(btnCancel)
						.addComponent(btnOk, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
				
		
	}

	private void createEvents() {
		// TODO Auto-generated method stub
		
		
		
	}
	
	   private void centerFrame() {

           Dimension windowSize = getSize();
           GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
           Point centerPoint = ge.getCenterPoint();

           int dx = centerPoint.x - windowSize.width / 2;
           int dy = centerPoint.y - windowSize.height / 2;    
           setLocation(dx, dy);
   }
}
